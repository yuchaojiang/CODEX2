.onLoad <- function(lib,pkg) {
   		library.dynam("seqCBS",pkg,lib)
	}
